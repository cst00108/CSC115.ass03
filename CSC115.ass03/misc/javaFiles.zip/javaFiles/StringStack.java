/*
 * The shell of the class, to be completed as part of the CSC115 Assignment 3 : Calculator.
 */

/*
 * NOTE TO STUDENT:
 * Fill in any of the parts that have the comment:
	//*******COMPLETE*******//
 * Do not change method headers or code that has been supplied.
 * All methods must be properly commented.
 * Please delete all messages to you, including this one, before submitting.
 */
public class StringStack {

	private Node head;

	public boolean isEmpty() {
	//*******COMPLETE*******//
	}

	public String pop() {
	//*******COMPLETE*******//
	}

	public String peek() {
	//*******COMPLETE*******//
	}

	public void push(String item) {
	//*******COMPLETE*******//
	}

	public void popAll() {
	//*******COMPLETE*******//
	}
}
